# React Native Weather App

This is the react-native Weather App with various features. We will be using Open Weather API for this purpose. This API is completely free to use. You can checkout the detailed tutorial on the making of this amazing app [Here](https://youtu.be/zs9ke8jmGxA)

### Screens

| ![](assets/images/Screenshot.jpg) | ![](assets/images/Screenshot-1.jpg) |
| :-------------: | :-------------: |
